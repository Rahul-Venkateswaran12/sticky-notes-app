from django.test import TestCase
from django.urls import reverse
from .models import Note
from .forms import NoteForm

class NoteModelTest(TestCase):
    def setUp(self):
        # Create a test note
        Note.objects.create(title='Test Note', content='This is test content.')

    def test_note_has_title(self):
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, 'Test Note')

    def test_note_has_content(self):
        note = Note.objects.get(id=1)
        self.assertEqual(note.content, 'This is test content.')

    def test_note_str(self):
        note = Note.objects.get(id=1)
        self.assertEqual(str(note), 'Test Note')

class NoteViewTest(TestCase):
    def setUp(self):
        # Create a test note for views
        self.note = Note.objects.create(title='Test Note', content='This is test content.')

    def test_note_list_view(self):
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')

    def test_note_detail_view(self):
        response = self.client.get(reverse('note_detail', args=[self.note.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')
        self.assertContains(response, 'This is test content.')

    def test_note_create_view_get(self):
        response = self.client.get(reverse('note_create'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')

    def test_note_create_view_post(self):
        data = {'title': 'New Note', 'content': 'New content'}
        response = self.client.post(reverse('note_create'), data)
        self.assertEqual(response.status_code, 302)  # Redirect
        self.assertTrue(Note.objects.filter(title='New Note').exists())

    def test_note_update_view_get(self):
        response = self.client.get(reverse('note_update', args=[self.note.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'notes/note_form.html')

    def test_note_update_view_post(self):
        data = {'title': 'Updated Note', 'content': 'Updated content'}
        response = self.client.post(reverse('note_update', args=[self.note.pk]), data)
        self.assertEqual(response.status_code, 302)  # Redirect
        updated_note = Note.objects.get(pk=self.note.pk)
        self.assertEqual(updated_note.title, 'Updated Note')

    def test_note_delete_view(self):
        response = self.client.get(reverse('note_delete', args=[self.note.pk]))  # Assuming GET for delete (your view uses GET)
        self.assertEqual(response.status_code, 302)  # Redirect
        self.assertFalse(Note.objects.filter(pk=self.note.pk).exists())

class NoteFormTest(TestCase):
    def test_valid_form(self):
        data = {'title': 'Valid Title', 'content': 'Valid Content'}
        form = NoteForm(data=data)
        self.assertTrue(form.is_valid())

    def test_invalid_form_no_title(self):
        data = {'content': 'Content only'}
        form = NoteForm(data=data)
        self.assertFalse(form.is_valid())
